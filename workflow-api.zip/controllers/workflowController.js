const Workflow = require('../models/workflow');
const Step = require('../models/step');
const topoSort = require('../utils/topoSort');

exports.createWorkflow = async (req, res) => {
  const workflow = new Workflow(req.body);
  await workflow.save();
  res.json({ status: 'created', workflow });
};

exports.addStep = async (req, res) => {
  const step = new Step({ ...req.body, workflow_str_id: req.params.workflowId });
  await step.save();
  res.json({ status: 'step_added', step });
};

exports.addDependency = async (req, res) => {
  const { step, prerequisite } = req.body;
  if (step === prerequisite) {
    return res.status(400).json({ error: 'Self-dependency not allowed' });
  }
  const stepDoc = await Step.findOne({ step_str_id: step, workflow_str_id: req.params.workflowId });
  if (!stepDoc) return res.status(404).json({ error: 'Step not found' });
  stepDoc.prerequisites.push(prerequisite);
  await stepDoc.save();
  res.json({ status: 'dependency_added' });
};

exports.getWorkflowDetails = async (req, res) => {
  const steps = await Step.find({ workflow_str_id: req.params.workflowId });
  res.json({ steps });
};

exports.getExecutionOrder = async (req, res) => {
  const steps = await Step.find({ workflow_str_id: req.params.workflowId });
  try {
    const order = topoSort(steps);
    res.json({ executionOrder: order });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};