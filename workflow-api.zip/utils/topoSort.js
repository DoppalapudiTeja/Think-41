module.exports = function topoSort(steps) {
  const graph = {}, visited = {}, result = [];

  steps.forEach(s => graph[s.step_str_id] = s.prerequisites || []);

  function visit(node, ancestors = []) {
    if (ancestors.includes(node)) {
      throw new Error('Circular dependency detected');
    }

    if (!visited[node]) {
      ancestors.push(node);
      graph[node].forEach(dep => visit(dep, ancestors));
      visited[node] = true;
      result.push(node);
    }
  }

  Object.keys(graph).forEach(visit);
  return result.reverse();
};