const express = require('express');
const router = express.Router();
const workflowController = require('../controllers/workflowController');

router.post('/', workflowController.createWorkflow);
router.post('/:workflowId/steps', workflowController.addStep);
router.post('/:workflowId/dependencies', workflowController.addDependency);
router.get('/:workflowId/details', workflowController.getWorkflowDetails);
router.get('/:workflowId/executionOrder', workflowController.getExecutionOrder);

module.exports = router;