const mongoose = require('mongoose');

const workflowSchema = new mongoose.Schema({
  workflow_str_id: String,
  name: String
});

module.exports = mongoose.model('Workflow', workflowSchema);