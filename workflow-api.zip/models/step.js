const mongoose = require('mongoose');

const stepSchema = new mongoose.Schema({
  step_str_id: String,
  workflow_str_id: String,
  description: String,
  prerequisites: [String]
});

module.exports = mongoose.model('Step', stepSchema);